# Revision history for `glslang`

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](https://semver.org/).

## NEXT

* Deprecate the HLSL front-end. It will be removed at the next major version.
  See issue #4210 for details.
* Add support for GL_EXT_opacity_micromap_ray_query_mode

## 16.6.0 2026-09-10

### New Extensions

* Implement `GL_EXT_cooperative_matrix_maintenance1`
* Implement `GL_EXT_optional_input_attachment_index`
* Implement `DebugEntryPoint` for `NonSemantic.Shader.DebugInfo` 102

### `SPV_KHR_abort` / `abortEXT`

* Require the first parameter of `abortEXT` to be a string literal, emit an error if it is not
* Require the first parameter of `printf` to be a string literal, emit an error if it is not
* Fix abort message struct layout for matrix, vector, and aggregate arguments
* Pack the abort message with scalar layout when the shader requests `GL_EXT_scalar_block_layout`
* Pack the abort message with scalar layout unconditionally so that consumers use one fixed set of rules
* Fix abort message type to use separate value and laid out types, removing invalid `ArrayStride` on constant types
* Fix `abort` to handle boolean and opaque types correctly

### API Changes

* Add access to the source entry point in the C API

### Bug Fixes

* Fix relaxed Vulkan access chain traversal for buffer references
* Fix 32-bit identity fillers used in 16-bit matrix constructors
* Fix out-of-bounds slot access for `atomic_uint` in `reserveResourceSlot`
* Fix out-of-bounds read when folding component-wise intrinsics on matrices
* Fix out-of-bounds dereference on undeclared ray tracing location
* Fix out-of-bounds read on empty `entryPoints` in `postProcessFeatures`
* Fix out-of-bounds read on short `coopMatPerElementNV` argument list
* Fix crash on empty struct initializers in cascading error mode
* Guard empty block member list in `getBlockSize`
* Validate argument count in `decomposeStructBufferMethods`
* Require constant scope and semantics operands in `memorySemanticsCheck`
* Fix string escaping in preprocessed output
* Fix `Aligned` decoration on `buffer_reference` swizzle-store read-modify-write load
* Fold bit-cast conversions as constant expressions
* Fold hyperbolic functions (`sinh`, `cosh`, `tanh`, `asinh`, `acosh`, `atanh`) as constant expressions
* Improve parsing of `#pragma STDGL`

### Performance

* Replace linear search with a hash table for composite and struct constant creation in the SPIR-V builder

## 16.5.0 2026-07-31

### New Extensions

* Implement `GLSL_EXT_split_barrier` / `SPV_EXT_split_barrier`
* Implement `GLSL_QCOM_multiple_wait_queues`
* Implement `GLSL_QCOM_image_processing3`
* Implement `GL_EXT_function_control_attributes`

### API Changes

* Expose `TVarEntryInfo` as part of the public API in `ShaderLang.h`

### Bug Fixes

* Fix undefined shifts and signed overflow in `#if` expression evaluation
* Fix out-of-bounds read when indexing `idInstruction` and `idDescriptor`
* Fix null dereference in iomapper when `uniformVarMap` is empty
* Fix out-of-bounds read on empty array initializer in `convertInitializerList`
* Fix stack overflow on deeply nested macro invocations, capping macro expansion depth at 200 and emitting an error
* Fix out-of-bounds read in `handlePragma` when `#pragma STDGL` has fewer than 4 tokens
* Fix crash in preprocessor output when a backslash-newline continuation appears at end of input due to column underflow
* Fix crash on excess `#endif` directives when a malformed `#if` expression desynchronizes `elseSeen`/`ifdepth` preprocessor counters
* Fix out-of-bounds write in `memberRemapper` for nested `buffer_reference` blocks
* Fix out-of-bounds read on long vector index in `checkIndex`

### Other

* Update SPIR-V size optimization and HLSL legalization pass lists to match spirv-tools, and add performance optimization option
* Increase `input_attachment_index` limit to `INT_MAX`
* Print compile and link error logs to stderr instead of stdout

## 16.4.0 2026-07-14

### Descriptor Heap

* Implement `GLSL_EXT_structured_descriptor_heap` with SPIR-V layout generation, heap offset access, buffer references, matrix layout decorations, and correct `readonly`/`writeonly` qualifier propagation for buffer and image descriptors
* Fix descriptor heap-bound buffer access to use typed pointers
* Omit `NonUniform` decoration when using descriptor heaps, as the SPIR-V spec does not require it
* Add `--relax-set-binding-limits` option to allow large `layout(set)` and `layout(binding)` values for descriptor heap-style workflows with sparse set spaces
* Reject combined image samplers with `descriptor_heap`

### Compute Shader Derivatives

* Fix `GL_KHR_compute_shader_derivatives` regressions on shaders using the `GL_NV` variant
* Update compute shader derivative rules to allow texture operations with implicit derivatives without extensions, falling back to LoD 0

### New Extensions

* Implement `GL_EXT_ocp_microscaling_types`
* Implement `GL_NV_cooperative_matrix_decode_vector`
* Add basic support for `GL_NV_desktop_lowp_mediump`
* Implement `GL_EXT_opacity_micromap_ray_query_mode`

### Bug Fixes

* Fix generated decoration string from `UTF8EncodingKHR` to `UTFEncodingKHR`
* Fix missing SPIR-V extension emission for `float16` derivative functions with `SPV_AMD_gpu_shader_half_float`
* Apply `NoContraction` decoration to `dot()` when `noContraction` is set
* Fix `OpStore` of buffer device address pointer to use 8-byte alignment, consistent with loads
* Fix `RayTracingOpacityMicromapKHR` capability emission to only occur when `gl_RayFlagsForceOpacityMicromap2StateEXT` is actually used, fixing SPIR-V validation failures in ray query shaders outside ray-tracing pipeline stages
* Fix `setInvertY()` to apply Y-inversion to GLSL vertex, geometry, and tessellation-evaluation shaders (previously only affected HLSL)
* Fix `.length()` on arrays of long/cooperative vectors to use `OpArrayLength` instead of a constant component count
* Fix unnecessary cooperative matrix conversions when creating arrays of KHR cooperative matrices
* Add error for cooperative matrix `*=` with bf16/fp8 scalar operands
* Fix out-of-bounds access in `elseSeen` at maximum `#if`/`#ifdef` nesting depth
* Fix out-of-bounds read on empty struct texture template types
* Fix crash in `layoutObjectCheck` when accessing members of an empty block
* Emit an error when HLSL [numthreads] is given more than three arguments instead of crashing the compiler.
* Emit error when attempting to convert a literal string to an incompatible type
* Fix `abortKHR` to preserve the original user-defined string without modification
* Fix out-of-bounds indexing in `TDefaultIoResolverBase::addStage` when a negative `EShLanguage` value is passed

### Other

* Add `--discard-is-terminate` option to emit `OpTerminateInvocation` instead of `OpDemoteToHelperInvocation` for GLSL `discard` when targeting SPIR-V 1.6+
* Add REUSE license compliance infrastructure

## 16.3.0 2026-05-01
### Deprecation Notice
* Deprecate the HLSL front-end. See issue #4210 for details.

### Other changes
* Support GL_NV_explicit_typecast
* Raise the maximum limit for specialization constant IDs
* Add explicit 8-bit and 16-bit type support for bitfieldReverse
* Implement system include directives for the standalone wrapper
* Check for invalid usage of gl_WorkGroupSize components
* HLSL: Provide string error context only if token is a string
* Fix layoutDescriptorStride bitfield truncation for large stride values
* GL_EXT_long_vector with 2-4 components no longer require LongVector capability
* Fix alignment of guard blocks
* Fix ShaderDebugInfo having invalid line numbers when generating SPIRV 1.0
* Replace ostringstream with string concat during #include preprocessing
* Check for bad parameters on long vector type
* HLSL: Check for bad integer argument on Load*, Store*, Interlocked*
* HLSL: handle type error for ternary operator
* HLSL: Ensure scope is popped even when method body fails to parse
* Avoid unneccessary copies in SpirvIntrinsics.cpp
* Unconditionally emit debug source for include files when using non-semantic debug info
* Support bfloat16 and float8 tensors
* Add small type capabilities for GLSL.STD.450
* Add initial support for NonSemantic.Shader.DebugInfo 101
* Fix access chains for GL_ARM_tensors with raw descriptor heap accesses
* Support GL_KHR_compute_shader_derivatives
* Require a quad or linear layout qualifier to be specified for GL_KHR_compute_shader_derivatives
* Supportx SPV_KHR_constant_data and SPV_KHR_abort

## 16.2.0 2026-01-22
* Allow gl_FragDepth identifier to be redeclared
* Replace 'GL_TASK(MESH)_SHADER_NV' with 'GL_TASK(MESH)_SHADER_EXT'
* Scalarize swizzled MeshEXT stores
* Support GL_EXT_long_vector
* Add missing preamble #define for GL_EXT_nontemporal_keyword
* Support GL_NV_push_constant_bank
* Support GL_EXT_descriptor_heap

## 16.1.0 2025-12-01
* Avoid emitting OpCapability RuntimeDescriptorArray when unnecessary
* Improve compilation speed when debug infomation is enabled
* Fix Debug Info for Retargeted Builtins
* Support GL_EXT_shader_invocation_reorder
* Add checks to coopMatMulAdd
* Implement stringify operator
* Add ES support for depth layout qualifier
* Add debug info for hitObjectNV
* Emit a DebugGlobalVariable instead of DebugLocalVariable for rayQueryEXT
* Add debug info for constant variable
* Improve debug line to point declaration
* Fix bugs in buffer reference alignment
* Reject string operands in binary and select ops
* Support GL_EXT_shader_64bit_indexing
* Support GLSL_EXT_uniform_buffer_unsized_array
* Add semantic check for cooperative vector loads/stores
* Improve the debug info name of opaque (sampler) types
* Support IO mapping of combined samplers and acceleration structures
* Fix bug in debug info for bool types inside SSBO/UBO
* Fix bug in debug info for struct member names
* Add methods for entry point and invert-y to C interface

## 16.0.0 2025-09-25
### Breaking changes
* Remove spirv-remapper (ported to SPIRV-Tools as canonicalize-ids optimization pass)

### Other changes
* Emit error for in/out structs containing booleans
* Fix contradictory layout link errors
* Improve error checks for float8 math
* Fix bug in cooperative matrix load/store handling of array slices
* Update memory semantic validation rules to match update to Vulkan specification
* Simplify glslang grammar for identifier lists
* Fix erroneous parse errors in variable declarations using existing struct names
* Fix type conversions for createTensorLayout/ViewNV
* Fix OpAccessChain signed index issue for small unsigned integers
* Support GLSL_QCOM_cooperative_matrix_conversion
* Allow spec constant matrix use
* Fix inconsistent labeling of capability strings
* Fix crash on unnamed function parameters under relaxed rules
* Fix exported member functions in ShaderLang.h

## 15.4.0 2025-06-26
* Support GL_NV_gpu_shader5/GL_ARB_gpu_shader5
* Remove BUILD_SHARED_LIBS option (defer to built-in variable)
* Remap discard to OpDemoteToHelperInvocation
* Fix typos and improve readability of help message
* Support GLSL_QCOM_tile_shading
* Emit correct capability for linear swept sphere
* Support GL_EXT_float8_e5m2_e4m3
* Move E_SPV_ARM_cooperative_matrix_layouts into GLSL.ext.ARM.h
* Support GL_ARM_tensors

## 15.3.0 2025-04-24
* Fix CMake find_package on Windows when building shared libraries
* Fix crash calling coopMatLoadTensorNV on an array element
* Avoid reusing array types with stride when no stride is requested
* Fix non-ASCII comments
* Support GL_EXT_bfloat16
* Fix several issues with link-time implicit array size merging
* Support DebugSourceContinued
* LiveTraverser no longer traverses switch cases that are statically not accessed
* Implement optional cross-stage check for inputs with no matching outputs

## 15.2.0 2025-02-24
* Fix find_package on Windows when BUILD_SHARED_LIBS=ON
* Emit error if using in/out with struct pointer
* Emit SPV_EXT_opacity_micromap if GL extension is present
* Support GL_NV_linear_swept_spheres
* Support GLSL_EXT_nontemporal_keyword
* Support GL_NV_cluster_acceleration_structure
* Support GL_NV_cooperative_vector
* Check SparseTextureOffset non-const parameters
* Support GL_EXT_texture_offset_non_const
* Revert cross-stage check for missing outputs
* Support EXT_integer_dot_product
* Add support for OpTypeRayQueryKHR and OpTypeAccelerationStructureKHR to SPVRemapper

## 15.1.0 2024-12-13
* Add Vulkan 1.4 target and client
* Improve conversion of uniform block to push constant
* Improve cross stage error reporting by reporting proper stager rather than "unkwown stage"
* Add warning if forward declaration uses layout qualifiers
* Implement GLSL_NV_cooperative_matrix2
* Emit OpModfStruct instead of depracated OpModf
* Add link-time cross stage optimization
* Add column to DebugLexicalBlock
* Propagate errors from symbol table initialization
* Fix nonsemantic debuginfo line attribution for cooperative matrix

## 15.0.0 2024-09-23
### Breaking changes
* Explicitly export all symbols that are part of the public API and hide other symbols by default

### Other changes
* Allow building glslang without the SPIR-V backend using the new ENABLE_SPIRV build option
* Add setResourceSetBinding method to the API
* Add interface to get the GLSL IO mapper and resolver
* Allow compute derivative modes when the workgroup dimensions are spec constants
* Improve debug location of branch/return instructions
* Silence preprocessor '#' error reporting in inactive #if/#ifdef/#elif/#else blocks
* Apply GLSL memory decorations to top-level OpVariable
* Move definition of GLSLANG_EXPORT to visibility.h
* Merge ancillary libraries into main glslang library and stub originals
* Add public setSourceFile and addSourceText methods to TShader class
* Add type checks for hitObjectNV
* Add optimizerAllowExpandedIDBound to SpvOptions
* Add SpvTools.h back to public headers 
* Add cross-stage check for missing outputs
* Fix HLSL offsets for non-buffers
* Add types and functions for IO mapping to API
* Add function to set preprocessed code to API
* Add set/get version functions to API
* Expose setGlobalUniform functions to API
* Don't emit debug instructions before an OpPhi
* Add command-line and API option to enable reporting column location for compiler errors
* Improve location aliasing checks
* Support constant expression calculated by matrixCompMult
* Fix crash caused by atomicCounter() use without arguments
* Fix multi-line function call line numbers
* Add line info to OpDebugDeclare for function parameters
* Fix HLSL OpDebugFunction file name
* Fix duplicate decorations
* Enable compilation of glslang without thread support for WASI

## 14.3.0 2024-06-25
* Generate vector constructions more efficiently when sizes match
* Skip identity conversions for 8-bit and 16-bit types
* Add cmake aliases for public libraries
* Support ARM extended matrix layout
* Emit debug info for buffer references
* Add support for OpExtInstWithForwardRefsKHR
* Generate SPV_EXT_replicated_compisites when requested by pragma
* Reuse loads generated for repeated function arguments
* Fix gl_HitT alias of gl_RayTmax
* Fix some cases where invalid SPIR-V was being generated when using separate samplers
* Add back layoutLocation to public API

## 14.2.0 2024-05-02
* Improve checking for location aliasing errors
* Fix undefined behavior in parser
* Add bounds check to gl_SampleMask
* Fix alignment and padding of matrices consuming one vector
* Remove duplicate SPIR-V decorations
* Check for exponent overflow in float parser
* Fix bug in relaxed verification rules
* Fix disassembly of debugBreak
* Fix bug when importing SPIR-V extended intruction set
* Fix issues with the interaction of cooperative_matrix and spirv_intrinsics
* Support SPV_QCOM_image_processing2
* Support files with UTF8BOM character

## 14.1.0 2024-03-08
* Add a new --abosute-path command-line option to output absolute paths in error messages
* Support GL_EXT_control_flow_attributes2
* Support GL_ARB_shading_language_include
* Fix HLSL built-in passthrough via inout
* Enable -Wimplicit-fallthrough and fix warnings
* Fix -Wmissing_field_initializer warnings
* Document supported dependencies in known_good.json
* Clear spirv vector before use
* Emit debug info for accelerationStructure and rayQuery variables
* Support NV_shader_atomic_fp16_vector
* Support GL_EXT_expect_assume_support
* Allow external control of whether glslang will be tested or installed
* Improve debug source and line info
* Support GL_KHR_shader_subgroup_rotate
* Add SPIRV-Tools-opt dependency if ENABLE_OPT
* Support EXT_shader_quad_control
* Add OpAssumeTrueKHR and OpExpectKHR
* Support GL_EXT_maximal_reconvergence
* Remove generation of deprecated Target.cmake files
* Fix array size of gl_SampleMask and gl_SampleMaskIn
* Support GL_ARB_texture_multisample_extension
* Emit DebugTypePointer when non-semantic debug info is enabled

## 14.0.0 2023-12-21

### Breaking changes
* The legacy libraries named HLSL and OGLCompiler have been removed. To avoid future disruptions, please use cmake's find_package mechanism rather than hardcoding library dependencies.
* Only the headers that are part of glslang's public interface are included in the install target.
* Remove OVERRIDE_MSVCCRT cmake option.

### Other changes
* Fix spv_options initialization
* Fix line number for OpDebugFunction and OpDebugScope for function
* Fix SPV_KHR_cooperative_matrix enumerants
* Fix nullptr crash
* Fix GL_ARB_shader_storage_buffer_object version
* Fix interpolant ES error
* Generate DebugValue for constant arguments
* Overflow/underflow out-of-range floats to infinity/0.0 respectively
* Support SV_ViewID keywords for HLSL
* Implement relaxed rule for opaque struct members
* Add BUILD_WERROR cmake option
* Add GLSLANG_TESTS cmake option
* Always generate OpDebugBasicType for bool type
* Fix GLSL parsing of '#' when not preceded by space or tab
* Fix GL_ARB_bindless_texture availability
* Support GL_EXT_draw_instanced extension
* Support GL_EXT_texture_array extension
* Fix conversion of 64-bit unsigned integer constants to bool
* Output 8-bit and 16-bit capabilities when appropriate for OpSpecConstant

## 13.1.1 2023-10-16
* Initialize compile_only field in C interface

## 13.1.0 2023-10-13
* Support GL_EXT_texture_shadow_lod
* Support GL_NV_displacement_micromap
* Fix ByteAddressBuffer when used a function parameter
* Add more verbose messages if SPIRV-Tools is not found
* Fix names for explicitly sized types when emitting nonsemantic debug info
* Emit error for r-value arguments in atomic memory operations
* Add --no-link option
* Beautify preprocessor output format
* Fix race condition in glslangValidator
* Only set LocalSizeId mode when necessary
* Don't emit invalid debug info for buffer references

## 13.0.0 2023-08-23

### Breaking changes
* Simplify PoolAlloc via thread_local
  * Remove InitializeDLL functions
  * Remove OSDependent TLS functions
* Remove GLSLANG_WEB and GLSLANG_WEB_DEVEL code paths

### Other changes
* Raise CMAKE minimum to 3.17.2
* Support GL_KHR_cooperative_matrix 
* Support GL_QCOM_image_processing_support
* Support outputting each module to a filename with spirv-remap
* Generate an error when gl_PrimitiveShaderRateEXT is used without enabling the extension
* Improve layout checking when GL_EXT_spirv_intrinsics is enabled

## 12.3.1 2023-07-20

### Other changes
* Improve backward compatibility for glslangValidator rename on Windows

## 12.3.0 2023-07-19

### Other changes
* Rename glslangValidator to glslang and create glslangValidator symlink
* Support HLSL binary literals
* Add missing initialization members for web
* Improve push_constant upgrading
* Fix race condition in spirv remap
* Support pre and post HLSL qualifier validation
* Force generateDebugInfo when non-semantic debug info is enabled
* Exit with error if output file cannot be written
* Fix struct member buffer reference decorations

## 12.2.0 2023-05-17

### Other changes
* Support GLSL_EXT_shader_tile_image
* Support GL_EXT_ray_tracing_position_fetch
* Support custom include callbacks via the C API
* Add preamble-text command-line option
* Accept variables as parameters of spirv_decorate_id
* Fix generation of conditionals with a struct result
* Fix double expansion of macros
* Fix DebugCompilationUnit scope
* Improve line information

## 12.1.0 2023-03-21

### Other changes
* Reject non-float inputs/outputs for version less than 120
* Fix invalid BufferBlock decoration for SPIR-V 1.3 and above
* Add HLSL relaxed-precision float/int matrix expansions
* Block decorate Vulkan structs with RuntimeArrays
* Support InterlockedAdd on float types

## 12.0.0 2023-01-18

### Breaking changes
* An ABI was accidentally broken in #3014. Consequently, we have incremented the major revision number.

### Other changes
* Add support for ARB_bindless_texture.
* Add support for GL_NV_shader_invocation_reorder.
* Fix const parameter debug types when using NonSemantic.Shader.DebugInfo.100.
* Fix NonSemantic.Shader.DebugInfo.100 disassembly.
* Fix MaxDualSourceDrawBuffersEXT usage.
* Fix structure member reference crash.

## 11.13.0 2022-12-06

### Other changes
* Make HelperInvocation accesses volatile for SPIR-V 1.6.
* Improve forward compatibility of ResourceLimits interface 
* Remove GLSLANG_ANGLE

## 11.12.0 2022-10-12

### Other changes
* Update generator version
* Add support for GL_EXT_mesh_shader
* Add support for NonSemantic.Shader.DebugInfo.100
* Make OpEmitMeshTasksEXT a terminal instruction
* Make gl_SubGroupARB a flat in int in Vulkan
* Add support for GL_EXT_opacity_micromap
* Add preamble support to C interface

## 11.11.0 2022-08-11

### Other changes
* Add OpSource support to C interface
* Deprecate samplerBuffer for spirv1.6 and later
* Add support for SPV_AMD_shader_early_and_late_fragment_tests

## 11.10.0 2022-06-02

### Other changes
* Generate OpLine before OpFunction
* Add support for VK_EXT_fragment_shader_barycentric
* Add whitelist filtering for debug comments in SPIRV-Remap
* Add support for GL_EXT_ray_cull_mask

## 11.9.0 2022-04-06

### Other changes
* Add GLSL version override functionality
* Add eliminate-dead-input-components to -Os
* Add enhanced-msgs option
* Explicitly use Python 3 for builds

## 11.8.0 2022-01-27

### Other changes
* Add support for SPIR-V 1.6
* Add support for Vulkan 1.3
* Add --hlsl-dx-position-w option

## 11.7.0 2021-11-11

### Other changes
* Add support for targeting Vulkan 1.2 in the C API

## 11.6.0 2021-08-25

### Other changes
* Atomic memory function only for shader storage block member or shared variable
* Add support for gl_MaxVaryingVectors for ogl
* Fix loading bool arrays from interface blocks
* Generate separate stores for partially swizzled memory stores
* Allow layout(std430) uniform with GL_EXT_scalar_block_layout
* Support for pragma STDGL invariant(all)
* Support for GL_NV_ray_tracing_motion_blur

## 11.5.0 2021-06-23

### Other changes
* Implement GLSL_EXT_shader_atomic_float2
* Implement GL_EXT_spirv_intrinsics
* Fixed SPIR-V remapper not remapping OpExtInst instruction set IDs
* only declare compatibility gl_ variables in compatibility mode
* Add support for float spec const vector initialization
* Implement GL_EXT_subgroup_uniform_control_flow.
* Fix arrays dimensioned with spec constant sized gl_WorkGroupSize
* Add support for 64bit integer scalar and vector types to bitCount() builtin

## 11.4.0 2021-04-22

### Other changes
* Fix to keep source compatible with CMake 3.10.2

## 11.3.0 2021-04-21

### Other changes
* Added --depfile
* Added --auto-sampled-textures
* Now supports InterpolateAt-based functions
* Supports cross-stage automatic IO mapping
* Supports GL_EXT_vulkan_glsl_relaxed (-R option)

## 11.2.0 2021-02-18

### Other changes
* Removed Python requirement when not building with spirv-tools
* Add support for GL_EXT_shared_memory_block
* Implement GL_EXT_null_initializer
* Add CMake support for Fuschia

## 11.1.0 2020-12-07

### Other changes
* Added ray-tracing extension support

## 11.0.0 2020-07-20

### Breaking changes

#### Visual Studio 2013 is no longer supported

[As scheduled](https://github.com/KhronosGroup/glslang/blob/9eef54b2513ca6b40b47b07d24f453848b65c0df/README.md#planned-deprecationsremovals),
Microsoft Visual Studio 2013 is no longer officially supported. Please upgrade
to at least Visual Studio 2015.

## 10.15.3847 2020-07-20

### Breaking changes

* The following files have been removed:
  * `glslang/include/revision.h`
  * `glslang/include/revision.template`

The `GLSLANG_MINOR_VERSION` and `GLSLANG_PATCH_LEVEL` defines have been removed
from the public headers. \
Instead each build script now uses the new `build_info.py`
script along with the `build_info.h.tmpl` and this `CHANGES.md` file to generate
the glslang build-time generated header `glslang/build_info.h`.

The new public API to obtain the `glslang` version is `glslang::GetVersion()`.

### Other changes
* `glslang` shared objects produced by CMake are now `SONAME` versioned using
   [Semantic Versioning 2.0.0](https://semver.org/).
